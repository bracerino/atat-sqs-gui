#!/usr/bin/env bash
set -euo pipefail

RUNPY_SOURCE="run.py"
SUMMARY_OUT="energy_summary_per_atom.csv"
PLOT_OUT="energy_per_atom.png"
PYTHON_BIN="python3"

plot_now() {
  "$PYTHON_BIN" - <<'PY'
import csv
import re
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

summary = Path("energy_summary_per_atom.csv")
out = Path("energy_per_atom.png")
out_std0 = Path("energy_std_around_zero.png")

rows = []

def parse_key(label):
    m = re.match(r"(\d+)x(\d+)x(\d+)", label)
    if m:
        return tuple(int(x) for x in m.groups())
    return (10**9, 10**9, 10**9)

with summary.open(newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        folder = (row.get("folder") or "").strip()
        if not folder:
            continue
        try:
            y = float(row["total_energy_mean_eV_per_atom"])
            e = float(row["total_energy_std_eV_per_atom"])
        except:
            continue
        m = re.match(r"^supercell_(.+)$", folder)
        label = m.group(1) if m else folder
        rows.append((label, y, e))

if not rows:
    raise SystemExit(0)

rows.sort(key=lambda r: parse_key(r[0]))

labels = [r[0] for r in rows]
ys = [r[1] for r in rows]
es = [r[2] for r in rows]

x = list(range(len(labels)))

plt.figure()
plt.errorbar(x, ys, yerr=es, fmt="o", capsize=4)
plt.xticks(x, labels, rotation=45, ha="right")
plt.xlabel("supercell")
plt.ylabel("Energy per atom (eV/atom)")
plt.tight_layout()
plt.savefig(out, dpi=200)

plt.figure()
plt.errorbar(x, [0.0]*len(labels), yerr=es, fmt="o", capsize=4)
plt.xticks(x, labels, rotation=45, ha="right")
plt.xlabel("supercell")
plt.ylabel("Standard deviation (eV/atom)")
plt.tight_layout()
plt.savefig(out_std0, dpi=200)
PY
}

[[ -f "$RUNPY_SOURCE" ]] || exit 1

if [[ ! -s "$SUMMARY_OUT" ]]; then
  echo "folder,atoms,total_energy_mean_eV_per_atom,total_energy_std_eV_per_atom" > "$SUMMARY_OUT"
fi

shopt -s nullglob
for d in */ ; do
  [[ -d "$d" ]] || continue
  folder="${d%/}"

  cp -f "$RUNPY_SOURCE" "$folder/"

  (
    cd "$folder"
    "$PYTHON_BIN" run.py
  )

  energy_csv="$folder/results/energy_results.csv"
  [[ -f "$energy_csv" ]] || continue

  read -r atoms mean_pa std_pa < <(
    awk -F',' '
      NR==1{
        for(i=1;i<=NF;i++){
          if($i=="energy_eV") e=i
          if($i=="num_atoms") a=i
        }
        next
      }
      NR>1{
        na=$a
        en=$e
        gsub(/^[ \t\r\n"]+|[ \t\r\n"]+$/, "", na)
        gsub(/^[ \t\r\n"]+|[ \t\r\n"]+$/, "", en)
        if(first_atoms==""){ first_atoms=na+0 }
        x=en+0
        n++
        sum+=x
        sumsq+=x*x
      }
      END{
        if(n<1 || first_atoms<=0) exit 2
        mean=sum/n
        var=(sumsq/n)-(mean*mean)
        if(var<0) var=0
        std=sqrt(var)
        printf "%.10g %.10g %.10g\n", first_atoms, mean/first_atoms, std/first_atoms
      }
    ' "$energy_csv"
  ) || continue

  echo "$folder,$atoms,$mean_pa,$std_pa" >> "$SUMMARY_OUT"

  plot_now
done
