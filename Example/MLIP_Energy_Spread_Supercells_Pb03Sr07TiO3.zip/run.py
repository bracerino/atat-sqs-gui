#!/usr/bin/env python3
"""
MACE Calculation Script (Local POSCAR Files)
Generated on: 2026-02-10 18:38:07
Calculation Type: Energy Only
Model: MACE-MATPES-r2SCAN-0 (medium) - r2SCAN
Device: cuda
Precision: float32

This script reads POSCAR files from the current directory.
Place your POSCAR files in the same directory as this script before running.
"""

import os
import time
import numpy as np
import json
import pandas as pd
from datetime import datetime
from pathlib import Path
import random
from copy import deepcopy
import threading
import queue
import zipfile
import io

# Set threading before other imports
os.environ['OMP_NUM_THREADS'] = '5'

import torch
torch.set_num_threads(5)

# ASE imports
from ase import Atoms
from ase.io import read, write
from ase.optimize import (
    BFGS, LBFGS, FIRE,
    BFGSLineSearch, LBFGSLineSearch,
    GoodOldQuasiNewton, MDMin, GPMin
)
from ase.optimize.sciopt import SciPyFminBFGS, SciPyFminCG
from ase.constraints import FixAtoms, ExpCellFilter, UnitCellFilter

# PyMatGen imports
from pymatgen.core import Structure
from pymatgen.io.ase import AseAtomsAdaptor

# MACE imports
try:
    from mace.calculators import mace_mp, mace_off
    MACE_AVAILABLE = True
except ImportError:
    try:
        from mace.calculators import MACECalculator
        MACE_AVAILABLE = True
    except ImportError:
        MACE_AVAILABLE = False

# CHGNet imports
try:
    from chgnet.model.model import CHGNet
    from chgnet.model.dynamics import CHGNetCalculator
    CHGNET_AVAILABLE = True
except ImportError:
    CHGNET_AVAILABLE = False

# SevenNet imports (requires torch 2.6 compatibility)
try:
    torch.serialization.add_safe_globals([slice])  # Required for torch 2.6
    from sevenn.calculator import SevenNetCalculator
    SEVENNET_AVAILABLE = True
except ImportError:
    SEVENNET_AVAILABLE = False

# MatterSim imports
try:
    from mattersim.forcefield import MatterSimCalculator
    MATTERSIM_AVAILABLE = True
except ImportError:
    MATTERSIM_AVAILABLE = False

# ORB imports
try:
    from orb_models.forcefield import pretrained
    from orb_models.forcefield.calculator import ORBCalculator
    ORB_AVAILABLE = True
except ImportError:
    ORB_AVAILABLE = False

# Nequix imports
try:
    from nequix.calculator import NequixCalculator
    NEQUIX_AVAILABLE = True
except ImportError:
    NEQUIX_AVAILABLE = False

#MAD-PET
try:
    from pet_mad.calculator import PETMADCalculator
    PETMAD_AVAILABLE = True
except ImportError:
    PETMAD_AVAILABLE = False


# Check if any calculator is available
if not (MACE_AVAILABLE or CHGNET_AVAILABLE or SEVENNET_AVAILABLE or MATTERSIM_AVAILABLE or ORB_AVAILABLE or NEQUIX_AVAILABLE or PETMAD_AVAILABLE):
    print("❌ No MLIP calculators available!")
    print("Please install at least one:")
    print("  - MACE: pip install mace-torch")
    print("  - CHGNet: pip install chgnet") 
    print("  - SevenNet: pip install sevenn")
    print("  - MatterSim: pip install mattersim")
    print("  - ORB: pip install orb-models")
    print("  - Nequix: pip install nequix")
    print("  - PET-MAD: pip install pet-mad")
    exit(1)
else:
    available_models = []
    if MACE_AVAILABLE:
        available_models.append("MACE")
    if CHGNET_AVAILABLE:
        available_models.append("CHGNet")
    if SEVENNET_AVAILABLE:
        available_models.append("SevenNet")
    if MATTERSIM_AVAILABLE:
        available_models.append("MatterSim")
    if ORB_AVAILABLE:
        available_models.append("ORB")
    if NEQUIX_AVAILABLE:
        available_models.append("Nequix")
    if PETMAD_AVAILABLE:
        available_models.append("PET-MAD")
    print(f"✅ Available MLIP models: {', '.join(available_models)}")



def wrap_positions_in_cell(atoms):
    wrapped_atoms = atoms.copy()
    fractional_coords = wrapped_atoms.get_scaled_positions()
    wrapped_fractional = fractional_coords % 1.0
    wrapped_atoms.set_scaled_positions(wrapped_fractional)
    return wrapped_atoms


def get_lattice_parameters(atoms):
    cell = atoms.get_cell()
    a, b, c = np.linalg.norm(cell, axis=1)

    def angle_between_vectors(v1, v2):
        cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
        cos_angle = np.clip(cos_angle, -1.0, 1.0)
        return np.degrees(np.arccos(cos_angle))

    alpha = angle_between_vectors(cell[1], cell[2])
    beta = angle_between_vectors(cell[0], cell[2])
    gamma = angle_between_vectors(cell[0], cell[1])

    volume = np.abs(np.linalg.det(cell))

    return {
        'a': a, 'b': b, 'c': c,
        'alpha': alpha, 'beta': beta, 'gamma': gamma,
        'volume': volume
    }


def get_atomic_composition(atoms):
    symbols = atoms.get_chemical_symbols()
    total_atoms = len(symbols)

    composition = {}
    for symbol in symbols:
        composition[symbol] = composition.get(symbol, 0) + 1

    concentrations = {}
    for element, count in composition.items():
        concentrations[element] = (count / total_atoms) * 100

    return composition, concentrations



def save_elastic_constants_to_csv(structure_name, elastic_tensor, csv_filename="results/elastic_constants_cij.csv"):


    elastic_data = {
        'structure_name': structure_name,
        'C11_GPa': float(elastic_tensor[0, 0]),
        'C12_GPa': float(elastic_tensor[0, 1]),
        'C13_GPa': float(elastic_tensor[0, 2]),
        'C14_GPa': float(elastic_tensor[0, 3]),
        'C15_GPa': float(elastic_tensor[0, 4]),
        'C16_GPa': float(elastic_tensor[0, 5]),
        'C21_GPa': float(elastic_tensor[1, 0]),
        'C22_GPa': float(elastic_tensor[1, 1]),
        'C23_GPa': float(elastic_tensor[1, 2]),
        'C24_GPa': float(elastic_tensor[1, 3]),
        'C25_GPa': float(elastic_tensor[1, 4]),
        'C26_GPa': float(elastic_tensor[1, 5]),
        'C31_GPa': float(elastic_tensor[2, 0]),
        'C32_GPa': float(elastic_tensor[2, 1]),
        'C33_GPa': float(elastic_tensor[2, 2]),
        'C34_GPa': float(elastic_tensor[2, 3]),
        'C35_GPa': float(elastic_tensor[2, 4]),
        'C36_GPa': float(elastic_tensor[2, 5]),
        'C41_GPa': float(elastic_tensor[3, 0]),
        'C42_GPa': float(elastic_tensor[3, 1]),
        'C43_GPa': float(elastic_tensor[3, 2]),
        'C44_GPa': float(elastic_tensor[3, 3]),
        'C45_GPa': float(elastic_tensor[3, 4]),
        'C46_GPa': float(elastic_tensor[3, 5]),
        'C51_GPa': float(elastic_tensor[4, 0]),
        'C52_GPa': float(elastic_tensor[4, 1]),
        'C53_GPa': float(elastic_tensor[4, 2]),
        'C54_GPa': float(elastic_tensor[4, 3]),
        'C55_GPa': float(elastic_tensor[4, 4]),
        'C56_GPa': float(elastic_tensor[4, 5]),
        'C61_GPa': float(elastic_tensor[5, 0]),
        'C62_GPa': float(elastic_tensor[5, 1]),
        'C63_GPa': float(elastic_tensor[5, 2]),
        'C64_GPa': float(elastic_tensor[5, 3]),
        'C65_GPa': float(elastic_tensor[5, 4]),
        'C66_GPa': float(elastic_tensor[5, 5])
    }

    if os.path.exists(csv_filename):
        df_existing = pd.read_csv(csv_filename)

        if structure_name in df_existing['structure_name'].values:
            df_existing.loc[df_existing['structure_name'] == structure_name, list(elastic_data.keys())] = list(elastic_data.values())
        else:
            df_new_row = pd.DataFrame([elastic_data])
            df_existing = pd.concat([df_existing, df_new_row], ignore_index=True)

        df_existing.to_csv(csv_filename, index=False)
    else:
        df_new = pd.DataFrame([elastic_data])
        df_new.to_csv(csv_filename, index=False)

    print(f"  💾 Elastic constants saved to {csv_filename}")


def append_optimization_summary(filename, structure_name, initial_atoms, final_atoms, 
                               initial_energy, final_energy, convergence_status, steps, selective_dynamics=None):

    initial_lattice = get_lattice_parameters(initial_atoms)
    final_lattice = get_lattice_parameters(final_atoms)
    composition, concentrations = get_atomic_composition(final_atoms)

    energy_change = final_energy - initial_energy
    volume_change = ((final_lattice['volume'] - initial_lattice['volume']) / initial_lattice['volume']) * 100

    a_change = ((final_lattice['a'] - initial_lattice['a']) / initial_lattice['a']) * 100
    b_change = ((final_lattice['b'] - initial_lattice['b']) / initial_lattice['b']) * 100
    c_change = ((final_lattice['c'] - initial_lattice['c']) / initial_lattice['c']) * 100

    alpha_change = final_lattice['alpha'] - initial_lattice['alpha']
    beta_change = final_lattice['beta'] - initial_lattice['beta']
    gamma_change = final_lattice['gamma'] - initial_lattice['gamma']

    comp_formula = "".join([f"{element}{composition[element]}" for element in sorted(composition.keys())])

    elements = sorted(composition.keys())
    conc_values = [concentrations[element] for element in elements]
    conc_string = " ".join([f"{element}:{conc:.1f}" for element, conc in zip(elements, conc_values)])

    constraint_info = "None"
    if selective_dynamics is not None:
        total_atoms = len(selective_dynamics)
        completely_fixed = sum(1 for flags in selective_dynamics if not any(flags))
        partially_fixed = sum(1 for flags in selective_dynamics if not all(flags) and any(flags))
        free_atoms = sum(1 for flags in selective_dynamics if all(flags))

        constraint_parts = []
        if completely_fixed > 0:
            constraint_parts.append(f"{completely_fixed}complete")
        if partially_fixed > 0:
            constraint_parts.append(f"{partially_fixed}partial")
        if free_atoms > 0:
            constraint_parts.append(f"{free_atoms}free")

        constraint_info = ",".join(constraint_parts)

    file_exists = os.path.exists(filename)

    with open(filename, 'a') as f:
        if not file_exists:
            header = "Structure,Formula,Atoms,Composition,Steps,Convergence,E_initial_eV,E_final_eV,E_change_eV,E_per_atom_eV,a_init_A,b_init_A,c_init_A,alpha_init_deg,beta_init_deg,gamma_init_deg,V_init_A3,a_final_A,b_final_A,c_final_A,alpha_final_deg,beta_final_deg,gamma_final_deg,V_final_A3,a_change_percent,b_change_percent,c_change_percent,alpha_change_deg,beta_change_deg,gamma_change_deg,V_change_percent"
            f.write(header + "\n")

        line = f"{structure_name},{comp_formula},{len(final_atoms)},{conc_string},{steps},{convergence_status},{initial_energy:.6f},{final_energy:.6f},{energy_change:.6f},{final_energy/len(final_atoms):.6f},{initial_lattice['a']:.6f},{initial_lattice['b']:.6f},{initial_lattice['c']:.6f},{initial_lattice['alpha']:.3f},{initial_lattice['beta']:.3f},{initial_lattice['gamma']:.3f},{initial_lattice['volume']:.6f},{final_lattice['a']:.6f},{final_lattice['b']:.6f},{final_lattice['c']:.6f},{final_lattice['alpha']:.3f},{final_lattice['beta']:.3f},{final_lattice['gamma']:.3f},{final_lattice['volume']:.6f},{a_change:.3f},{b_change:.3f},{c_change:.3f},{alpha_change:.3f},{beta_change:.3f},{gamma_change:.3f},{volume_change:.3f}"
        f.write(line + "\n")


def read_poscar_with_selective_dynamics(filename):
    atoms = read(filename)

    with open(filename, 'r') as f:
        lines = f.readlines()

    selective_dynamics = None
    if len(lines) > 7:
        line_7 = lines[7].strip().upper()
        if line_7.startswith('S'):
            selective_dynamics = []
            coord_start = 9

            for i in range(coord_start, len(lines)):
                line = lines[i].strip()
                if not line or line.startswith('#'):
                    continue

                parts = line.split()
                if len(parts) >= 6:
                    try:
                        flags = [parts[j].upper() == 'T' for j in [3, 4, 5]]
                        selective_dynamics.append(flags)
                    except (IndexError, ValueError):
                        break
                elif len(parts) == 3:
                    break

    return atoms, selective_dynamics


def write_poscar_with_selective_dynamics(atoms, filename, selective_dynamics=None, comment="Optimized structure"):
    if selective_dynamics is not None and len(selective_dynamics) == len(atoms):
        with open(filename, 'w') as f:
            f.write(f"{comment}\n")
            f.write("1.0\n")

            cell = atoms.get_cell()
            for i in range(3):
                f.write(f"  {cell[i][0]:16.12f}  {cell[i][1]:16.12f}  {cell[i][2]:16.12f}\n")

            symbols = atoms.get_chemical_symbols()
            unique_symbols = []
            symbol_counts = []
            for symbol in symbols:
                if symbol not in unique_symbols:
                    unique_symbols.append(symbol)
                    symbol_counts.append(symbols.count(symbol))

            f.write("  " + "  ".join(unique_symbols) + "\n")
            f.write("  " + "  ".join(map(str, symbol_counts)) + "\n")

            f.write("Selective dynamics\n")
            f.write("Direct\n")

            scaled_positions = atoms.get_scaled_positions()
            for symbol in unique_symbols:
                for i, atom_symbol in enumerate(symbols):
                    if atom_symbol == symbol:
                        pos = scaled_positions[i]
                        flags = selective_dynamics[i]
                        flag_str = "  ".join(["T" if flag else "F" for flag in flags])
                        f.write(f"  {pos[0]:16.12f}  {pos[1]:16.12f}  {pos[2]:16.12f}   {flag_str}\n")
    else:
        write(filename, atoms, format='vasp', direct=True, sort=True)
        with open(filename, 'r') as f:
            lines = f.readlines()
        with open(filename, 'w') as f:
            f.write(f"{comment}\n")
            for line in lines[1:]:
                f.write(line)


def apply_selective_dynamics_constraints(atoms, selective_dynamics):
    """Apply selective dynamics as ASE constraints with support for partial fixing."""
    if selective_dynamics is None or len(selective_dynamics) != len(atoms):
        return atoms

    # Check if we have any constraints to apply
    has_constraints = False
    for flags in selective_dynamics:
        if not all(flags):  # If any direction is False (fixed)
            has_constraints = True
            break

    if not has_constraints:
        print(f"  🔄 Selective dynamics found but all atoms are completely free")
        return atoms

    # Apply constraints
    try:
        from ase.constraints import FixCartesian, FixAtoms

        constraints = []
        constraint_summary = []

        # Group atoms by constraint type
        completely_fixed_indices = []
        partial_constraints = []

        for i, flags in enumerate(selective_dynamics):
            if not any(flags):  # All directions fixed (F F F)
                completely_fixed_indices.append(i)
            elif not all(flags):  # Some directions fixed (partial)
                # ASE FixCartesian uses True for FIXED directions (opposite of VASP)
                # VASP: T=free, F=fixed
                # ASE:  T=fixed, F=free
                mask = [not flag for flag in flags]  # Invert the flags
                partial_constraints.append((i, mask))

        # Apply complete fixing
        if completely_fixed_indices:
            constraints.append(FixAtoms(indices=completely_fixed_indices))
            constraint_summary.append(f"{len(completely_fixed_indices)} atoms completely fixed")

        # Apply partial constraints - create individual FixCartesian for each atom
        if partial_constraints:
            partial_groups = {}
            for atom_idx, mask in partial_constraints:
                mask_key = tuple(mask)
                if mask_key not in partial_groups:
                    partial_groups[mask_key] = []
                partial_groups[mask_key].append(atom_idx)

            for mask, atom_indices in partial_groups.items():
                # Create individual FixCartesian constraints for each atom
                for atom_idx in atom_indices:
                    constraints.append(FixCartesian(atom_idx, mask))

                fixed_dirs = [dir_name for dir_name, is_fixed in zip(['x', 'y', 'z'], mask) if is_fixed]
                constraint_summary.append(f"{len(atom_indices)} atoms fixed in {','.join(fixed_dirs)} directions")

        # Apply all constraints
        if constraints:
            atoms.set_constraint(constraints)

            total_constrained = len(completely_fixed_indices) + len(partial_constraints)
            print(f"  📌 Applied selective dynamics to {total_constrained}/{len(atoms)} atoms:")
            for summary in constraint_summary:
                print(f"    - {summary}")

    except ImportError:
        # Fallback: only handle completely fixed atoms
        print(f"  ⚠️ FixCartesian not available, only applying complete atom fixing")
        fixed_indices = []
        for i, flags in enumerate(selective_dynamics):
            if not any(flags):  # All directions False (completely fixed)
                fixed_indices.append(i)

        if fixed_indices:
            from ase.constraints import FixAtoms
            constraint = FixAtoms(indices=fixed_indices)
            atoms.set_constraint(constraint)
            print(f"  📌 Applied complete fixing to {len(fixed_indices)}/{len(atoms)} atoms")
        else:
            print(f"  ⚠️ No completely fixed atoms found, partial constraints not supported")

    except Exception as e:
        # If FixCartesian fails for any reason, fall back to complete fixing only
        print(f"  ⚠️ FixCartesian failed ({str(e)}), falling back to complete atom fixing only")
        fixed_indices = []
        for i, flags in enumerate(selective_dynamics):
            if not any(flags):  # All directions False (completely fixed)
                fixed_indices.append(i)

        if fixed_indices:
            from ase.constraints import FixAtoms
            constraint = FixAtoms(indices=fixed_indices)
            atoms.set_constraint(constraint)
            print(f"  📌 Applied complete fixing to {len(fixed_indices)}/{len(atoms)} atoms (fallback)")
        else:
            print(f"  ⚠️ No completely fixed atoms found")

    return atoms



def generate_concentration_combinations(substitutions):
    """Generate all possible combinations of concentrations."""
    import itertools

    # Check if any element has multiple concentrations
    has_multiple = any('concentration_list' in sub_info and len(sub_info['concentration_list']) > 1
                       for sub_info in substitutions.values())

    if not has_multiple:
        # Convert single concentrations to the original format
        single_combo = {}
        for element, sub_info in substitutions.items():
            if 'concentration_list' in sub_info:
                concentration = sub_info['concentration_list'][0]
            else:
                concentration = sub_info.get('concentration', 0.5)

            element_count = sub_info.get('element_count', 0)
            n_substitute = int(element_count * concentration)

            single_combo[element] = {
                'new_element': sub_info['new_element'],
                'concentration': concentration,
                'n_substitute': n_substitute,
                'n_remaining': element_count - n_substitute
            }
        return [single_combo]

    # Generate all combinations for multiple concentrations
    elements = []
    concentration_lists = []

    for element, sub_info in substitutions.items():
        elements.append(element)
        if 'concentration_list' in sub_info:
            concentration_lists.append(sub_info['concentration_list'])
        else:
            concentration_lists.append([sub_info.get('concentration', 0.5)])

    combinations = []
    for conc_combo in itertools.product(*concentration_lists):
        combo_substitutions = {}
        for i, element in enumerate(elements):
            concentration = conc_combo[i]
            element_count = substitutions[element].get('element_count', 0)
            n_substitute = int(element_count * concentration)

            combo_substitutions[element] = {
                'new_element': substitutions[element]['new_element'],
                'concentration': concentration,
                'n_substitute': n_substitute,
                'n_remaining': element_count - n_substitute
            }

        combinations.append(combo_substitutions)

    return combinations

def create_combination_name(combo_substitutions):
    """Create a descriptive name for a concentration combination."""
    name_parts = []

    for original_element, sub_info in combo_substitutions.items():
        new_element = sub_info['new_element']
        concentration = sub_info['concentration']
        remaining_concentration = 1 - concentration

        if concentration == 0:
            # No substitution, pure original element
            name_parts.append(f"{original_element}100pct")
        elif concentration == 1:
            # Complete substitution
            if new_element == 'VACANCY':
                name_parts.append(f"{original_element}0pct_100pct_vacant")
            else:
                name_parts.append(f"{new_element}100pct")
        else:
            # Partial substitution
            remaining_pct = int(remaining_concentration * 100)
            substitute_pct = int(concentration * 100)

            if new_element == 'VACANCY':
                name_parts.append(f"{original_element}{remaining_pct}pct_{substitute_pct}pct_vacant")
            else:
                name_parts.append(f"{original_element}{remaining_pct}pct_{new_element}{substitute_pct}pct")

    return "_".join(name_parts)

def sort_concentration_combinations(concentration_combinations):
    """Sort concentration combinations for consistent ordering."""
    def get_sort_key(combo_substitutions):
        sort_values = []
        for element in sorted(combo_substitutions.keys()):
            concentration = combo_substitutions[element]['concentration']
            sort_values.append(concentration)
        return tuple(sort_values)

    return sorted(concentration_combinations, key=get_sort_key)

def calculate_formation_energy(structure_energy, atoms, reference_energies):
    if structure_energy is None:
        return None

    element_counts = {}
    for symbol in atoms.get_chemical_symbols():
        element_counts[symbol] = element_counts.get(symbol, 0) + 1

    total_reference_energy = 0
    for element, count in element_counts.items():
        if element not in reference_energies or reference_energies[element] is None:
            return None
        total_reference_energy += count * reference_energies[element]

    total_atoms = sum(element_counts.values())
    formation_energy_per_atom = (structure_energy - total_reference_energy) / total_atoms
    return formation_energy_per_atom


def create_cell_filter(atoms, pressure, cell_constraint, optimize_lattice, hydrostatic_strain):
    pressure_eV_A3 = pressure * 0.00624150913

    if cell_constraint == "Full cell (lattice + angles)":
        if hydrostatic_strain:
            return ExpCellFilter(atoms, scalar_pressure=pressure_eV_A3, hydrostatic_strain=True)
        else:
            return ExpCellFilter(atoms, scalar_pressure=pressure_eV_A3)
    elif cell_constraint == "Tetragonal (a=b, optimize a and c)":
        from ase.constraints import FixSymmetry
        existing_constraints = atoms.constraints if hasattr(atoms, 'constraints') and atoms.constraints else []
        symmetry_constraint = FixSymmetry(atoms)
        atoms.set_constraint(existing_constraints + [symmetry_constraint])
        return ExpCellFilter(atoms, scalar_pressure=pressure_eV_A3)
    else:  # "Lattice parameters only (fix angles)"
        if hydrostatic_strain:
            return UnitCellFilter(atoms, scalar_pressure=pressure_eV_A3, hydrostatic_strain=True)
        else:
            mask = [optimize_lattice['a'], optimize_lattice['b'], optimize_lattice['c'], False, False, False]
            return UnitCellFilter(atoms, mask=mask, scalar_pressure=pressure_eV_A3)


class OptimizationLogger:
    def __init__(self, filename, max_steps, output_dir="optimized_structures", save_trajectory=True):
        self.filename = filename
        self.step_count = 0
        self.max_steps = max_steps
        self.step_times = []
        self.step_start_time = time.time()
        self.output_dir = output_dir
        self.save_trajectory = save_trajectory  
        self.trajectory = [] if save_trajectory else None

    def __call__(self, optimizer=None):
        current_time = time.time()

        if self.step_count > 0:
            step_time = current_time - self.step_start_time
            self.step_times.append(step_time)

        self.step_count += 1
        self.step_start_time = current_time

        if optimizer is not None and hasattr(optimizer, 'atoms'):
            if hasattr(optimizer.atoms, 'atoms'):
                atoms = optimizer.atoms.atoms
            else:
                atoms = optimizer.atoms

            forces = atoms.get_forces()
            max_force = np.max(np.linalg.norm(forces, axis=1))
            energy = atoms.get_potential_energy()

            # Calculate energy per atom
            energy_per_atom = energy / len(atoms)

            # Calculate energy change
            if hasattr(self, 'previous_energy') and self.previous_energy is not None:
                energy_change = abs(energy - self.previous_energy)
                energy_change_per_atom = energy_change / len(atoms)
            else:
                energy_change = float('inf')
                energy_change_per_atom = float('inf')
            self.previous_energy = energy

            try:
                stress = atoms.get_stress(voigt=True)
                max_stress = np.max(np.abs(stress))
            except:
                max_stress = 0.0

            lattice = get_lattice_parameters(atoms)

            if self.save_trajectory:
                self.trajectory.append({
                    'step': self.step_count,
                    'energy': energy,
                    'max_force': max_force,
                    'positions': atoms.positions.copy(),
                    'cell': atoms.cell.array.copy(),
                    'lattice': lattice.copy(),
                    'forces': forces.copy()
                })

            if len(self.step_times) > 0:
                avg_time = np.mean(self.step_times)
                remaining_steps = max(0, self.max_steps - self.step_count)
                estimated_remaining_time = avg_time * remaining_steps

                if avg_time < 60:
                    avg_time_str = f"{avg_time:.1f}s"
                else:
                    avg_time_str = f"{avg_time/60:.1f}m"

                if estimated_remaining_time < 60:
                    remaining_time_str = f"{estimated_remaining_time:.1f}s"
                elif estimated_remaining_time < 3600:
                    remaining_time_str = f"{estimated_remaining_time/60:.1f}m"
                else:
                    remaining_time_str = f"{estimated_remaining_time/3600:.1f}h"

                print(f"    Step {self.step_count}: E={energy:.6f} eV ({energy_per_atom:.6f} eV/atom), "
                      f"F_max={max_force:.4f} eV/Å, Max_Stress={max_stress:.4f} GPa, "
                      f"ΔE={energy_change:.2e} eV ({energy_change_per_atom:.2e} eV/atom) | "
                      f"Max. time: {remaining_time_str} ({remaining_steps} steps)")
            else:
                print(f"    Step {self.step_count}: E={energy:.6f} eV ({energy_per_atom:.6f} eV/atom), "
                      f"F_max={max_force:.4f} eV/Å, Max_Stress={max_stress:.4f} GPa, "
                      f"ΔE={energy_change:.2e} eV ({energy_change_per_atom:.2e} eV/atom)")




def main():
    start_time = time.time()
    print("🚀 Starting MACE calculation script...")
    print(f"📅 Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🔬 Calculation type: Energy Only")
    print(f"🤖 Model: MACE-MATPES-r2SCAN-0 (medium) - r2SCAN")
    print(f"💻 Device: cuda")
    print(f"🧵 CPU threads: {os.environ.get('OMP_NUM_THREADS', 'default')}")

    # Create output directories
    Path("optimized_structures").mkdir(exist_ok=True)
    Path("results").mkdir(exist_ok=True)


    # Find and validate POSCAR files in current directory
    print("\n📁 Looking for POSCAR files in current directory...")
    structure_files = sorted([f for f in os.listdir(".") if f.startswith("POSCAR") or f.endswith(".vasp") or f.endswith(".poscar")])

    if not structure_files:
        print("❌ No POSCAR files found in current directory!")
        print("Please place files starting with 'POSCAR' or ending with '.vasp' in the same directory as this script.")
        return

    print(f"✅ Found {len(structure_files)} structure files:")
    for i, filename in enumerate(structure_files, 1):
        try:
            atoms = read(filename)
            composition = "".join([f"{symbol}{list(atoms.get_chemical_symbols()).count(symbol)}" 
                                 for symbol in sorted(set(atoms.get_chemical_symbols()))])
            print(f"  {i}. {filename} - {composition} ({len(atoms)} atoms)")
        except Exception as e:
            print(f"  {i}. {filename} - ❌ Error: {str(e)}")

    # Setup calculator
    print("\n🔧 Setting up MLIP calculator...")
    device = "cuda"
    print(f"🔧 Initializing MACE foundation model from URL...")

    def download_mace_model(model_url):
        """Download MACE model from URL and cache it."""
        from pathlib import Path
        import urllib.request

        model_filename = model_url.split("/")[-1]
        cache_dir = Path.home() / ".cache" / "mace_foundation_models"
        cache_dir.mkdir(parents=True, exist_ok=True)
        model_path = cache_dir / model_filename

        if model_path.exists():
            print(f"✅ Using cached model: {model_filename}")
            return str(model_path)

        print(f"📥 Downloading {model_filename}... (this may take a few minutes)")
        try:
            urllib.request.urlretrieve(model_url, str(model_path))
            print(f"✅ Model downloaded and cached")
            return str(model_path)
        except Exception as e:
            print(f"❌ Download failed: {e}")
            if model_path.exists():
                model_path.unlink()
            raise

    try:
        from mace.calculators import mace_mp

        model_url = "https://github.com/ACEsuit/mace-foundations/releases/download/mace_matpes_0/MACE-matpes-r2scan-omat-ft.model"
        local_model_path = download_mace_model(model_url)
        print(f"📁 Model path: {local_model_path}")

        print(f"⚙️  Device: {device}")
        print(f"⚙️  Dtype: float32")

        calculator = mace_mp(
            model=local_model_path,
        device=device,
        default_dtype="float32"
        )
        print(f"✅ MACE foundation model initialized successfully on {device}")

    except Exception as e:
        print(f"❌ MACE initialization failed on {device}: {e}")
        if device == "cuda":
            print("⚠️ GPU initialization failed, falling back to CPU...")
            try:
                calculator = mace_mp(
                    model=local_model_path,
        device="cpu",
        default_dtype="float32"
                )
                print("✅ MACE initialized successfully on CPU (fallback)")
            except Exception as cpu_error:
                print(f"❌ CPU fallback also failed: {cpu_error}")
                raise cpu_error
        else:
            raise e

    # Run calculations
    print("\n⚡ Starting calculations...")
    calc_start_time = time.time()
    structure_files = sorted([f for f in os.listdir(".") if f.startswith("POSCAR") or f.endswith(".vasp") or f.endswith(".poscar")])
    results = []
    print(f"📊 Found {len(structure_files)} structure files")

    reference_energies = {}
    print("🔬 Calculating atomic reference energies...")
    all_elements = set()
    for filename in structure_files:
        atoms = read(filename)
        for symbol in atoms.get_chemical_symbols():
            all_elements.add(symbol)

    print(f"🧪 Found elements: {', '.join(sorted(all_elements))}")

    for i, element in enumerate(sorted(all_elements)):
        print(f"  📍 Calculating reference for {element} ({i+1}/{len(all_elements)})...")
        atom = Atoms(element, positions=[(0, 0, 0)], cell=[20, 20, 20], pbc=True)
        atom.calc = calculator
        reference_energies[element] = atom.get_potential_energy()
        print(f"  ✅ {element}: {reference_energies[element]:.6f} eV")
        iso_xyz_filename = f"optimized_structures/IsolatedAtom_{element}.xyz"
        forces = atom.get_forces()
        with open(iso_xyz_filename, "w") as f:
            f.write("1\n")
            lattice_string = "20.0 0.0 0.0 0.0 20.0 0.0 0.0 0.0 20.0"
            f.write(
                f'Lattice="{lattice_string}" '
                'Properties=species:S:1:pos:R:3:forces:R:3 '
                f'config_type=IsolatedAtom Energy={reference_energies[element]:.6f} pbc="F F F"\n'
            )
            f.write(
                f"{element}  {0.0:12.6f} {0.0:12.6f} {0.0:12.6f} "
                f"{forces[0][0]:12.6f} {forces[0][1]:12.6f} {forces[0][2]:12.6f}\n"
            )
        print(f"  💾 Saved isolated atom XYZ: {iso_xyz_filename}")

    for i, filename in enumerate(structure_files):
        print(f"\n📊 Processing structure {i+1}/{len(structure_files)}: {filename}")
        structure_start_time = time.time()
        try:
            atoms = read(filename)
            atoms.calc = calculator

            print(f"  🔬 Calculating energy for {len(atoms)} atoms...")
            energy = atoms.get_potential_energy()

            # Calculate forces
            print(f"  🔬 Calculating forces...")
            forces = atoms.get_forces()
            max_force = np.max(np.linalg.norm(forces, axis=1))

            # Get lattice parameters
            lattice = get_lattice_parameters(atoms)

            # Save XYZ file with lattice and force information
            base_name = filename.replace('.vasp', '').replace('.poscar', '').replace('POSCAR', '').replace('POSCAR_', '')
            if not base_name:
                base_name = f"structure_{i+1}"

            #xyz_filename = f"results/{base_name}_energy.xyz"
            xyz_filename = f"optimized_structures/{i+1}_{base_name}.xyz"
            print(f"  💾 Saving XYZ file: {xyz_filename}")

            with open(xyz_filename, 'w') as xyz_file:
                num_atoms = len(atoms)
                cell_matrix = atoms.get_cell()
                lattice_string = " ".join([f"{x:.6f}" for row in cell_matrix for x in row])

                # Write number of atoms
                xyz_file.write(f"{num_atoms}\n")

                # Write comment line with all information
                comment = (f'Energy={energy:.6f} Max_Force={max_force:.6f} '
                          f'a={lattice["a"]:.6f} b={lattice["b"]:.6f} c={lattice["c"]:.6f} '
                          f'alpha={lattice["alpha"]:.3f} beta={lattice["beta"]:.3f} gamma={lattice["gamma"]:.3f} '
                          f'Volume={lattice["volume"]:.6f} '
                          f'Lattice="{lattice_string}" '
                          f'Properties=species:S:1:pos:R:3:forces:R:3')
                xyz_file.write(f"{comment}\n")

                # Write atomic positions and forces
                symbols = atoms.get_chemical_symbols()
                positions = atoms.get_positions()
                for j, (symbol, pos, force) in enumerate(zip(symbols, positions, forces)):
                    xyz_file.write(f"{symbol} {pos[0]:12.6f} {pos[1]:12.6f} {pos[2]:12.6f} "
                                 f"{force[0]:12.6f} {force[1]:12.6f} {force[2]:12.6f}\n")

            result = {
                "structure": filename,
                "energy_eV": energy,
                "max_force_eV_per_A": max_force,
                "calculation_type": "energy_only",
                "num_atoms": len(atoms),
                "xyz_file": xyz_filename
            }

            formation_energy = calculate_formation_energy(energy, atoms, reference_energies)
            result["formation_energy_eV_per_atom"] = formation_energy

            print(f"  ✅ Energy: {energy:.6f} eV")
            if formation_energy is not None:
                print(f"  ✅ Formation energy: {formation_energy:.6f} eV/atom")
            else:
                print(f"  ⚠️ Could not calculate formation energy")
            structure_time = time.time() - structure_start_time
            print(f"  ⏱️ Structure time: {structure_time:.1f}s")


            results.append(result)

            # Save results after each structure completes
            df_results = pd.DataFrame(results)
            df_results.to_csv("results/energy_results.csv", index=False)
            print(f"  💾 Results updated and saved")

        except Exception as e:
            print(f"  ❌ Failed: {e}")
            results.append({"structure": filename, "error": str(e)})

            # Save results even for failed structures
            df_results = pd.DataFrame(results)
            df_results.to_csv("results/energy_results.csv", index=False)
            print(f"  💾 Results updated and saved (with error)")

    # Final summary save
    df_results = pd.DataFrame(results)
    df_results.to_csv("results/energy_results.csv", index=False)

    print(f"\n💾 Saved results to results/energy_results.csv")

    with open("results/energy_summary.txt", "w") as f:
        f.write("MACE Energy Calculation Results\n")
        f.write("=" * 40 + "\n\n")
        for result in results:
            if "error" not in result:
                f.write(f"Structure: {result['structure']}\n")
                f.write(f"Energy: {result['energy_eV']:.6f} eV\n")
                f.write(f"Atoms: {result['num_atoms']}\n")
                if "formation_energy_eV_per_atom" in result and result["formation_energy_eV_per_atom"] is not None:
                    f.write(f"Formation Energy: {result['formation_energy_eV_per_atom']:.6f} eV/atom\n")
                f.write("\n")
            else:
                f.write(f"Structure: {result['structure']} - ERROR: {result['error']}\n\n")

    print(f"💾 Saved summary to results/energy_summary.txt")

    # Generate energy plots
    print("\n📊 Generating energy plots...")
    successful_results = [r for r in results if "error" not in r]

    if len(successful_results) > 0:
        try:
            import matplotlib.pyplot as plt

            # Set global font sizes
            plt.rcParams.update({
                'font.size': 18,
                'axes.titlesize': 24,
                'axes.labelsize': 20,
                'xtick.labelsize': 18,
                'ytick.labelsize': 18,
                'legend.fontsize': 18,
                'figure.titlesize': 26
            })

            # Prepare data
            structure_names = [r["structure"] for r in successful_results]
            energies = [r["energy_eV"] for r in successful_results]

            # 1. Total Energy Plot
            plt.figure(figsize=(16, 12))
            bars = plt.bar(range(len(structure_names)), energies, color='steelblue', alpha=0.7)
            plt.xlabel('Structure', fontsize=22, fontweight='bold')
            plt.ylabel('Total Energy (eV)', fontsize=22, fontweight='bold')
            plt.title('Total Energy Comparison', fontsize=26, fontweight='bold', pad=20)
            plt.xticks(range(len(structure_names)), [name.replace('.vasp', '').replace('POSCAR_', '') for name in structure_names], 
                      rotation=45, ha='right', fontsize=18, fontweight='bold')
            plt.yticks(fontsize=18, fontweight='bold')

            # Extend y-axis to accommodate labels above bars
            y_min, y_max = plt.ylim()
            y_range = y_max - y_min
            plt.ylim(y_min, y_max + y_range * 0.15)

            # Add vertical value labels above bars
            for i, (bar, energy) in enumerate(zip(bars, energies)):
                plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + y_range * 0.02, 
                        f'{energy:.3f}', ha='center', va='bottom', fontsize=16, fontweight='bold', 
                        rotation=90, color='black')

            plt.tight_layout()
            plt.savefig('results/total_energy_comparison.png', dpi=300, bbox_inches='tight')
            plt.close()
            print("  ✅ Saved total energy plot: results/total_energy_comparison.png")

            # 2. Formation Energy Plot
            formation_energies = [r.get("formation_energy_eV_per_atom") for r in successful_results]
            valid_formation = [(name, fe) for name, fe in zip(structure_names, formation_energies) if fe is not None]

            if valid_formation:
                valid_names, valid_fe = zip(*valid_formation)

                plt.figure(figsize=(16, 12))
                colors = ['green' if fe == min(valid_fe) else 'orange' for fe in valid_fe]
                bars = plt.bar(range(len(valid_names)), valid_fe, color=colors, alpha=0.7)
                plt.xlabel('Structure', fontsize=22, fontweight='bold')
                plt.ylabel('Formation Energy (eV/atom)', fontsize=22, fontweight='bold')
                plt.title('Formation Energy per Atom Comparison', fontsize=26, fontweight='bold', pad=20)
                plt.xticks(range(len(valid_names)), [name.replace('.vasp', '').replace('POSCAR_', '') for name in valid_names], 
                          rotation=45, ha='right', fontsize=18, fontweight='bold')
                plt.yticks(fontsize=18, fontweight='bold')

                # Extend y-axis to accommodate labels (handle positive and negative values)
                y_min, y_max = plt.ylim()
                y_range = y_max - y_min

                # Check if we have negative values
                has_negative = any(fe < 0 for fe in valid_fe)
                has_positive = any(fe > 0 for fe in valid_fe)

                if has_negative and has_positive:
                    plt.ylim(y_min - y_range * 0.15, y_max + y_range * 0.15)
                elif has_negative and not has_positive:
                    plt.ylim(y_min - y_range * 0.15, y_max + y_range * 0.05)
                else:
                    plt.ylim(y_min - y_range * 0.05, y_max + y_range * 0.15)

                # Add vertical value labels outside bars
                for i, (bar, fe) in enumerate(zip(bars, valid_fe)):
                    if fe >= 0:
                        y_pos = bar.get_height() + y_range * 0.02
                        va_align = 'bottom'
                    else:
                        y_pos = bar.get_height() - y_range * 0.02
                        va_align = 'top'
                    plt.text(bar.get_x() + bar.get_width()/2, y_pos, 
                            f'{fe:.4f}', ha='center', va=va_align, fontsize=16, fontweight='bold', 
                            rotation=90, color='black')

                plt.tight_layout()
                plt.savefig('results/formation_energy_comparison.png', dpi=300, bbox_inches='tight')
                plt.close()
                print("  ✅ Saved formation energy plot: results/formation_energy_comparison.png")

            # 3. Relative Energy Plot
            if len(energies) > 1:
                min_energy = min(energies)
                relative_energies = [(e - min_energy) * 1000 for e in energies]  # Convert to meV

                plt.figure(figsize=(16, 12))
                colors = ['green' if re == 0 else 'orange' for re in relative_energies]
                bars = plt.bar(range(len(structure_names)), relative_energies, color=colors, alpha=0.7)
                plt.xlabel('Structure', fontsize=22, fontweight='bold')
                plt.ylabel('Relative Energy (meV)', fontsize=22, fontweight='bold')
                plt.title('Relative Energy Comparison (vs. Lowest Energy)', fontsize=26, fontweight='bold', pad=20)
                plt.xticks(range(len(structure_names)), [name.replace('.vasp', '').replace('POSCAR_', '') for name in structure_names], 
                          rotation=45, ha='right', fontsize=18, fontweight='bold')
                plt.yticks(fontsize=18, fontweight='bold')

                # Extend y-axis to accommodate labels above bars
                y_min, y_max = plt.ylim()
                y_range = max(relative_energies) if max(relative_energies) > 0 else 1
                plt.ylim(-y_range * 0.1, max(relative_energies) + y_range * 0.15)

                # Add vertical value labels above bars
                for i, (bar, re) in enumerate(zip(bars, relative_energies)):
                    if re > 0:
                        y_pos = bar.get_height() + y_range * 0.02
                        va_align = 'bottom'
                    else:
                        y_pos = y_range * 0.05  # Position above zero line for zero values
                        va_align = 'bottom'
                    plt.text(bar.get_x() + bar.get_width()/2, y_pos, 
                            f'{re:.1f}', ha='center', va=va_align, fontsize=16, fontweight='bold', 
                            rotation=90, color='black')

                plt.tight_layout()
                plt.savefig('results/relative_energy_comparison.png', dpi=300, bbox_inches='tight')
                plt.close()
                print("  ✅ Saved relative energy plot: results/relative_energy_comparison.png")

            # Reset matplotlib settings
            plt.rcParams.update(plt.rcParamsDefault)

        except ImportError:
            print("  ⚠️ Matplotlib not available. Install with: pip install matplotlib")
        except Exception as e:
            print(f"  ⚠️ Error generating plots: {e}")

    else:
        print("  ℹ️ No successful calculations to plot")


    total_time = time.time() - start_time
    calc_time = time.time() - calc_start_time
    print(f"\n✅ All calculations completed!")
    print(f"⏱️ Total time: {total_time/60:.1f} minutes")
    print(f"⏱️ Calculation time: {calc_time/60:.1f} minutes")
    print("📊 Check the results/ directory for output files")

if __name__ == "__main__":
    main()
