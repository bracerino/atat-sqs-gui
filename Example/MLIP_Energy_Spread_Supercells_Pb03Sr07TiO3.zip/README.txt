Supercell Size Analysis - Structure Files
============================================================

Directory Structure:

supercell_3x3x3/
  - 100 structures
  - 135 atoms per structure
  - Mean score: 0.8253

supercell_4x4x4/
  - 100 structures
  - 320 atoms per structure
  - Mean score: 0.9017

supercell_5x5x5/
  - 100 structures
  - 625 atoms per structure
  - Mean score: 0.9198

supercell_6x6x6/
  - 100 structures
  - 1080 atoms per structure
  - Mean score: 0.9366

supercell_7x7x7/
  - 100 structures
  - 1715 atoms per structure
  - Mean score: 0.9528

supercell_8x8x8/
  - 100 structures
  - 2560 atoms per structure
  - Mean score: 0.9601


File Naming Convention:
POSCAR_XXX_score_Y.YYYY.vasp
  - XXX: Sample ID (001, 002, ...)
  - Y.YYYY: Randomness score

Total Files: 600
